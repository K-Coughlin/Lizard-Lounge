from app import db, app

with app.app_context():
    db.drop_all()  # Optional: drop all tables if they exist
    db.create_all()  # This will recreate the tables based on your models
    print("SQLite database and tables recreated.")
