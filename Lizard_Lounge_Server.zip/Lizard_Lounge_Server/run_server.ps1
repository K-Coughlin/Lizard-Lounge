# Start Mosquitto broker in the background
Write-Host "Starting Mosquitto broker..."
Start-Process "mosquitto" -ArgumentList "-c", "`"C:\Program Files\mosquitto\mosquitto.conf`"", "-v"


# Wait for a moment to allow Mosquitto to initialize
Start-Sleep -Seconds 2

# Activate the virtual environment
Write-Host "Activating virtual environment..."
$env:VIRTUAL_ENV = ".\venv"   # Adjust the path to your venv if necessary
$env:PATH = "$env:VIRTUAL_ENV\Scripts;$env:PATH"
$env:PYTHONHOME = $env:VIRTUAL_ENV

# Activate the virtual environment using the correct path
& ".\venv\Scripts\Activate.ps1"  # Directly reference the correct relative path

# Start the Flask application
Write-Host "Starting Flask application..."
python ".\app.py"  # Run the Flask app (ensure 'app.py' is in the current directory)
