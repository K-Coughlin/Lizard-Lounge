from flask import Flask, render_template, jsonify, request, flash
import paho.mqtt.client as mqtt
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func, inspect, not_, text, desc
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
from flask_socketio import SocketIO
from flask_cors import CORS
from datetime import datetime
from pytz import timezone,UTC
import os
import json

eastern = timezone('US/Eastern')

##################### MQTT ##################### 

mqtt_broker = "localhost"
mqtt_port = 1883

def on_connect(client, userdata, flags, rc):
    print("Connected to MQTT with result code " + str(rc))
    client.subscribe("esp32/devices")
    client.subscribe("esp32/thresholds")
    client.subscribe("esp32/useralerts")

def add_device_status(d,s):
    now = current_time_eastern()

    with app.app_context():
        # Check the most recent entry for this device
        last = entries.query.filter_by(device=d).order_by(desc(entries.date_added)).first()

        # Only insert if no entry exists or it's from a different second
        if not last or last.date_added.astimezone(eastern).replace(microsecond=0) != now:
            entry = entries(device=d, state=s)
            db.session.add(entry)
            db.session.commit()

def on_message(client, userdata, msg):
    print(f"MQTT message received on {msg.topic}: {msg.payload.decode("utf-8")}")
    payload = msg.payload.decode("utf-8")
    if msg.topic == "esp32/devices":
      # Decode msg to add entry to SQL table for feedback peripheral activation
      json_payload = json.loads(payload) 
      # Grab the device and the status from payload
      d, s = next(iter(json_payload.items()))
      add_device_status(d,s)
    elif msg.topic == "esp32/useralerts":
        print("WORKED")
        socketio.emit('user_alert', {'alert': payload})
    #  
mqtt_client = mqtt.Client()
mqtt_client.on_connect = on_connect
mqtt_client.on_message = on_message
mqtt_client.connect(mqtt_broker, mqtt_port, 60)

##################### CREATE FLASK ##################### 
app = Flask(__name__)
app.secret_key = '123'

socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

##################### WEB SOCKET HANDLER ######################
@socketio.on('connect')
def handle_connect():
    print("Client connected via WebSocket")

@socketio.on('disconnect')
def handle_disconnect():
    print("Client disconnected from WebSocket")

@socketio.on('send_message')  # Example custom event to listen for messages from frontend
def handle_message(data):
    print(f"Received message: {data}")
    # Here, you can send a response back to the frontend if needed
    socketio.emit('response', {'message': 'Message received'})

##################### SQL ##################### 
# SQL Database
import os
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(basedir, 'instance', 'sensors.db')}"

# Initialize database
db = SQLAlchemy(app)

# Helper function for current time
def current_time_eastern():
    return datetime.now(eastern);
# Create Model
class entries(db.Model):

    # Sensor data
    id = db.Column(db.Integer, primary_key=True)
    hot_temperature = db.Column(db.Float, nullable=True)
    cool_temperature = db.Column(db.Float, nullable=True)
    hot_humidity = db.Column(db.Integer, nullable=True)
    cool_humidity = db.Column(db.Integer, nullable=True)

    date_added = db.Column(db.DateTime, default=current_time_eastern)

    # Event data
    device = db.Column(db.String(50), nullable=True)
    state = db.Column(db.String(10), nullable=True)

    # String
    def __repr__(self):
        return '<ID %r>' % self.id

Base = automap_base()
# Make sure to use the app's context when reflecting the database
with app.app_context():
    Base.prepare(db.engine, reflect=True)

    # Now, you can access your Entry class via automap
Entry = Base.classes.entries

devices = {
    "fan":"off",
    "pump":"off",
    "relay1":"off",
    "relay2":"off",
    "relay3":"off"
}

temps = {
    "temp1":0.0,
    "hum1":0.0,
    "temp2":0.0,
    "hum2":0.0,
}

sensors = {
    "UV":0.0,
    "water":0
}

thresholds = {
    "hot_temp":100,
    "low_temp":70,
    "hi_humid":50,
    "lo_humid":30,
    "lo_water":0,
    "hi_hot_dur":30000,
    "lo_cool_dur":30000,
    "alert_time":30000
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/peripherals')
def peripherals():
    return render_template('peripherals.html')

@app.route('/threshold')
def threshold_change():
    return render_template('threshold.html')

@app.route('/graphs')
def graph_page():
    return render_template('chart.html')

@app.route('/settings')
def settings_page():
    return render_template('settings.html')



# Single endpoint for updating temperature and humidity data
@app.route('/update_temps', methods=['POST'])
def update_temps():

    data = request.json  # Get the JSON payload

    # Update the global variables if the keys exist in the payload
    if 'temp1' in data:
        temps["temp1"] = round(float(data['temp1']), 2)
    if 'hum1' in data:
        temps["hum1"] = round(float(data['hum1']),2)
    if 'temp2' in data:
        temps["temp2"] = round(float(data['temp2']),2)
    if 'hum2' in data:
        temps["hum2"] = float(data['hum2'])

    # Save to database
    new_entry = entries(
        hot_temperature=temps["temp2"],
        cool_temperature=temps["temp1"],
        hot_humidity=temps["hum2"],
        cool_humidity=temps["hum1"]
    )
    db.session.add(new_entry)
    db.session.commit()
    # Return a success response
    return jsonify(success=True)

@app.route('/update_sensors', methods=['POST'])
def update_sensors():

    data = request.json  # Get the JSON payload

    if 'UV' in data:
        temps["UV"] = round(float(data['UV']),1)
    if 'water' in data:
        temps["water"] = int(data['water'])

    # Return a success response
    return jsonify(success=True)

@app.route('/toggle_device')
def toggle_device():
    device = request.args.get('device')
    new_state = request.args.get('state')
    
    if device in devices:
        devices[device] = new_state
        print(f"{device} state updated to: {new_state}")

        # Publish to MQTT
        payload = jsonify({device: new_state}).get_data(as_text=True)
        mqtt_client.publish("esp32/devices", payload)

        # add entry to SQL
        add_device_status(device,new_state)
        return jsonify({device: new_state})
    else:
        return jsonify({"error":"Device not found"}), 404

@app.route('/update_thresholds', methods=['POST'])
def update_thresholds():
    data = request.json  # Get the JSON payload

    # Update the global thresholds if the keys exist in the payload
    if 'hot_temp' in data:
        thresholds["hot_temp"] = float(data['hot_temp'])
    if 'low_temp' in data:
        thresholds["low_temp"] = float(data['low_temp'])
    if 'hi_humid' in data:
        thresholds["hi_humid"] = float(data['hi_humid'])
    if 'lo_humid' in data:
        thresholds["lo_humid"] = float(data['lo_humid'])

    # Add publishing mqtt to new topic thresholds
    # On arduino add code: if mqtty topic is thresholds, set thresholds to payload..
    # payload format: hot temp, hot hum, cold temp, cold hum
            # Publish to MQTT
    payload = jsonify(data).get_data(as_text=True)
    mqtt_client.publish("esp32/thresholds", payload)
    
    # Return a success response
    return jsonify(success=True)

@app.route('/get_combined_data')
def get_combined_data():
    combined_data = {
        "devices":devices,
        "temps":temps,
        "thresholds":thresholds,
        }
    return jsonify(combined_data)

@app.route('/graph-data')
def graph_data():
    all_entries = db.session.query(entries).order_by(entries.date_added).all()
    device_events = db.session.query(entries.date_added, entries.device, entries.state).filter(
        entries.state.isnot(None)
    ).all()

    temp_low = []
    temp_high = []
    humidity_low = []
    humidity_high = []

    for entry in all_entries:
        timestamp = entry.date_added.isoformat()
        if entry.cool_temperature is not None:
            temp_low.append({"x": timestamp, "y": entry.cool_temperature})
        if entry.hot_temperature is not None:
            temp_high.append({"x": timestamp, "y": entry.hot_temperature})
        if entry.cool_humidity is not None:
            humidity_low.append({"x": timestamp, "y": entry.cool_humidity})
        if entry.hot_humidity is not None:
            humidity_high.append({"x": timestamp, "y": entry.hot_humidity})

    # Annotations
    annotations = []
    for event in device_events:
        annotations.append({
            "type": "line",
            "scaleID": "x",
            "value": event.date_added.isoformat(),
            "borderColor": "rgba(255, 99, 132, 0.5)" if event.state == 'deactivated' else "rgba(75, 192, 192, 0.5)",
            "borderWidth": 2,
            "label": {
                "content": f"{event.device} {event.state}",
                "enabled": True,
                "position": "start"
            }
        })

    return jsonify({
        "temperature": {
            "low": temp_low,
            "high": temp_high
        },
        "humidity": {
            "low": humidity_low,
            "high": humidity_high
        },
        "annotations": annotations
    })

@app.route('/clear_db', methods=['POST'])
def clear_db():
    try:
        # Remove active database sessions
        db.session.remove()
        db.engine.dispose()

        # Clear all data from tables (without dropping the tables)
        db.session.execute(text('DELETE FROM entries'))  # Clear entries table
        db.session.commit()  # Commit the changes

        return jsonify(success=True, message="All data cleared.")

    except Exception as e:
        db.session.rollback()  # Rollback if something goes wrong
        return jsonify(success=False, error=str(e)), 500

if __name__ == '__main__':
    mqtt_client.loop_start()
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)
